
<?php $__env->startSection('head'); ?>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
  <?php endif; ?>
      <div class="main-body">
      
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="main-breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">User Profile</li>
              </ol>
            </nav>
            <!-- /Breadcrumb -->
      
            <div class="row gutters-sm">
              <div class="col-md-4 mb-3">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex flex-column align-items-center text-center">
                      <img src="<?php echo e(asset('images/user.png')); ?>" alt="Admin" class="rounded-circle" width="150">
                      <div class="mt-3">
                        <h4><?php echo e($user->name); ?></h4>
                        <hr>
                        <p class="text-secondary mb-1"><?php echo e($user->job); ?></p>
                       
                       <input type="button" value="Edit" name = "btnPassport" />
                       <input type="button" value="Cancel" name = "btnPassport" />
                       <div id="dvPassport" style="display: none">
                        <form method="POST" action="<?php echo e(route('changej')); ?>">
                          <?php echo csrf_field(); ?>
                        New Job:
                        <input id="new_job" type="text" class="form-control" name="new_job" required autocomplete="new_job">
                        <button type="submit" class="btn btn-dark">
                          <?php echo e(__('Change')); ?>

                      </button>
                        </form>
                    </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-8">
                <div class="card mb-3">
                  <div class="card-body">
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Name</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <?php echo e($user->name); ?>

                       
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Email</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <?php echo e($user->email); ?>

                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Phone</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        (239) 816-9029
                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Joined at</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <?php echo e($user->created_at); ?>

                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Password</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                       <!--<a href="<?php echo e(route('userpass')); ?>">Change Password</a>-->
                       <input type="button" value="Change" name = "btnPassword" />
                       <input type="button" value="Cancel" name = "btnPassword" />
                      </div>
                      <hr>
                    <div class="row">
                       <div id="dvPassword" style="display: none">
                        <form method="POST" action="<?php echo e(route('changep')); ?>">
                          <?php echo csrf_field(); ?>
                
                          <div class="form-group row">
                            <label for="current_password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Current Password')); ?></label>
                
                            <div class="col-md-6">
                                <input id="current_password" type="password" class="form-control" name="current_password" required autocomplete="current-password">
                            </div>
                        </div>
                          
                    <div class="form-group row">
                      <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('New Password')); ?></label>
                
                      <div class="col-md-6">
                          <input id="new_password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="new_password" required autocomplete="new-password">
                
                          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($message); ?></strong>
                              </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                
                  <div class="form-group row">
                      <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>
                
                      <div class="col-md-6">
                          <input id="new_password_confirmation" type="password" class="form-control" name="new_password_confirmation" required autocomplete="new-password-confirmation">
                      </div>
                  </div>
                
                  <div class="form-group row mb-0">
                      <div class="col-md-6 offset-md-4">
                          <button type="submit" class="btn btn-dark">
                              <?php echo e(__('Change')); ?>

                          </button>
                      </div>
                  </div>
                </form>
                    </div>
                      </div>
                    </div>
              </div>
            </div>
          </div>
      </div>
     <script type="text/javascript">
          $(function () {
              $("input[name=btnPassport]").click(function () {
                  if ($(this).val() == "Edit") {
                      $("#dvPassport").show();
                  } else {
                      $("#dvPassport").hide();
                  }
              });
          });
      </script>
          <script type="text/javascript">
            $(function () {
                $("input[name=btnPassword]").click(function () {
                    if ($(this).val() == "Change") {
                        $("#dvPassword").show();
                    } else {
                        $("#dvPassword").hide();
                    }
                });
            });
        </script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Timeshift\resources\views/user/test.blade.php ENDPATH**/ ?>