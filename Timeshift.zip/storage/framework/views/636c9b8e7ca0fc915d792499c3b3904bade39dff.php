
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<div class="row justify-content-center">
    <h2>Change your job</h2>
    </div>
    <br>
    <div class="card-body">
      <form method="POST" action="<?php echo e(route('changej')); ?>">
          <?php echo csrf_field(); ?>

          <div class="form-group row">
            <label for="new_job" class="col-md-4 col-form-label text-md-right"><?php echo e(__('New Job')); ?></label>

            <div class="col-md-6">
                <input id="new_job" type="text" class="form-control" name="new_job" required autocomplete="new_job">
            </div>
        </div>

  <div class="form-group row mb-0">
      <div class="col-md-6 offset-md-4">
          <button type="submit" class="btn btn-dark">
              <?php echo e(__('Change')); ?>

          </button>
      </div>
  </div>
</form>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Timeshift\resources\views/user/changejob.blade.php ENDPATH**/ ?>