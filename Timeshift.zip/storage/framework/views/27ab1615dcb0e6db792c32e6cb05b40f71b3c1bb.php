
<?php $__env->startSection('head'); ?>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  * {
    box-sizing: border-box;
  }
  .openBtn {
    display: flex;
    justify-content: left;
  }
  .openButton {
    border: none;
    border-radius: 5px;
    background-color: #1c87c9;
    color: white;
    padding: 14px 20px;
    cursor: pointer;
    position: fixed;
  }
  .loginPopup {
    position: relative;
    text-align: center;
    width: 100%;
  }
  .formPopup {
    display: none;
    position: fixed;
    left: 45%;
    top: 5%;
    transform: translate(-50%, 5%);
    border: 3px solid #999999;
    z-index: 9;
  }
  .formContainer {
    max-width: 300px;
    padding: 20px;
    background-color: #fff;
  }
  .formContainer input[type=text],
  .formContainer input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 20px 0;
    border: none;
    background: #eee;
  }
  .formContainer input[type=text]:focus,
  .formContainer input[type=password]:focus {
    background-color: #ddd;
    outline: none;
  }
  .formContainer .btn {
    padding: 12px 20px;
    border: none;
    background-color: #8ebf42;
    color: #fff;
    cursor: pointer;
    width: 100%;
    margin-bottom: 15px;
    opacity: 0.8;
  }
  .formContainer .cancel {
    background-color: #cc0000;
  }
  .formContainer .btn:hover,
  .openButton:hover {
    opacity: 1;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('message')): ?>
   <div class="alert alert-success">
      <?php echo e(session('message')); ?>

   </div>
<?php endif; ?>
    <div class="main-body">
    
          <!-- Breadcrumb -->
          <nav aria-label="breadcrumb" class="main-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item active" aria-current="page">User Profile</li>
            </ol>
          </nav>
          <!-- /Breadcrumb -->
    
         <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <img src="<?php echo e(asset('images/user.png')); ?>" alt="Admin" class="rounded-circle" width="150">
                    <div class="mt-3">
                      <h4><?php echo e($user->name); ?></h4>
                      <hr>
                      <p class="text-secondary mb-1"><var id="job"><?php echo e($user->job); ?></var></p>

                                            <div class="openBtn">
                        <button onclick="openForm1()"><strong>Change Job</strong></button>
                      </div>
                      <div class="loginPopup">
                        <div class="formPopup" id="popupForm2">
                          <form method="POST" action="<?php echo e(route('changej')); ?>" class="formContainer">
                            <?php echo csrf_field(); ?>
                            <h2>Change Job</h2>
                           <label for="email">
                              <strong>New Job</strong>
                            </label>
                            <input type="text" id="psw" placeholder="<?php echo e($user->job); ?>" name="new_job" required>
                            <button type="submit" class="btn">Change</button>
                            <button type="button" class="btn cancel" onclick="closeForm1()">Close</button>
                            
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Name</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo e($user->name); ?>

                     
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Email</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo e($user->email); ?>

                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Phone</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      (239) 816-9029
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Joined at</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo e($user->created_at); ?>

                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Password</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                     
                      <div class="openBtn">
                        <button onclick="openForm()"><strong>Change Password</strong></button>
                      </div>
                      <div class="loginPopup">
                        <div class="formPopup" id="popupForm1">
                          <form method="POST" action="<?php echo e(route('changep')); ?>" class="formContainer">
                            <?php echo csrf_field(); ?>
                            <h2>Change Password</h2>
                            <label for="psw">
                              <strong>Current Password</strong>
                            </label>
                            <input type="password" id="psw" placeholder="Current Password" name="current_password" required>
                            <label for="psw">
                              <strong>New Password</strong>
                            </label>
                            <input type="password" id="psw" placeholder="New Password" name="new_password" required>
                            <label for="psw">
                              <strong>Confirm Password</strong>
                            </label>
                            <input type="password" id="psw" placeholder="Confirm Password" name="new_password_confirmation" required>
                            <button type="submit" class="btn">Change</button>
                            <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
                            
                          </form>
                        </div>
                      </div>
                    </div>
                    <hr>
                  </div>
            </div>
          </div>
        </div>
    </div>
    </div>
    
           <script>
            function openForm() {
              document.getElementById("popupForm2").style.display = "none";
              document.getElementById("popupForm1").style.display = "block";
            }
            function closeForm() {
              document.getElementById("popupForm1").style.display = "none";
            }
          </script>
          <script>
            function openForm1() {
              document.getElementById("popupForm1").style.display = "none";
              document.getElementById("popupForm2").style.display = "block";
            }
            function closeForm1() {
              document.getElementById("popupForm2").style.display = "none";
            }
          </script>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Timeshift\resources\views/user/profile.blade.php ENDPATH**/ ?>