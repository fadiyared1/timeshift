
<?php $__env->startSection('content'); ?>
<div id="users_content" class="align-middle w-full sm:px-6 py-6">

    <?php if(session('success')): ?>
    <div id="sucgreen" class="px-3 py-2 mb-5 border border-green-800 rounded border-l-8 bg-green-200 text-sm text-green-700">
       <?php echo e(session('success')); ?>

    </div>
 <?php endif; ?>
 <?php if(session('error')): ?>
   <div id="error" class="px-3 py-2 mb-5 border border-red-800 rounded border-l-8 bg-red-200 text-sm text-red-700">
         <?php echo e(session('error')); ?>

   </div>
 <?php endif; ?>


<div id="table1" class="shadow border-b border-gray-200 sm:rounded-lg mb-10 divide-y divide-gray-200">

    <div class="grid custom-grid bg-gray-50 sm:rounded-t-lg">
        <div class="col-span-2 p-3 whitespace-no-wrap text-left text-sm leading-4 font-medium text-gray-500">
            Project
        </div>
    </div>

    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="grid custom-grid bg-white <?php if($pro->id == $proj){ echo 'bg-gray-200';} ?> ">
        <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
            <?php echo e($pro->name); ?>

        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tailwinduser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Timeshift\resources\views/user/projects.blade.php ENDPATH**/ ?>