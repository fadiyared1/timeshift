
<?php $__env->startSection('content'); ?>


                <!-- ////////////////////////////////////////////////////// Tags ////////////////////////////////////////////////////////// -->

                <!-- ////////////////////////////////////////////////////// Task Tracker ////////////////////////////////////////////////////////// -->
                <div id="task_tracker_content" class="active_tab py-6 align-middle inline-block w-full sm:px-6">

                    <!-- ////////////////////////////////////////////// top part //////////////////////////////////////////// -->
                    <div class="shadow border-b border-gray-200 sm:rounded-lg mb-10 divide-y divide-gray-200">
                        <div class="grid custom-grid bg-gray-50 sm:rounded-t-lg">

                            <div class="p-3 flex items-center text-xs leading-4 font-medium text-gray-500">
                                Task
                            </div>
                            <div class="p-3 flex items-center text-xs leading-4 font-medium text-gray-500">
                                Project
                            </div>
                            <div class="p-3 flex items-center text-xs leading-4 font-medium text-gray-500">
                                Type
                            </div>
                            <div class="p-3 flex items-center text-xs leading-4 font-medium text-gray-500">
                                Tags
                            </div>
                            <div class="p-3 flex items-center text-xs leading-4 font-medium text-gray-500">
                                Description
                            </div>
                            <div class="p-3 flex items-center text-xs leading-4 font-medium text-gray-500">
                                Latest Comment
                            </div>

                            <div class="p-3 flex items-center justify-center text-xs leading-4 font-medium text-gray-500 col-span-2">
                                Start - End
                            </div>
                            <div class=""></div>
                            <div class=""></div>

                        </div>

                        <!-- Odd row -->
                        <div class="grid custom-grid bg-white sm:rounded-b-lg">
                            <div class="px-3 py-2">
                                <input type="text" class="border border-1 w-full outline-none px-0.5 text-gray-500 text-sm rounded-sm" placeholder="Current Task ">
                            </div>
                            <div class="px-3 py-2">
                                <select multiple class="chosen border border-1 w-full outline-none px-0.5 text-gray-500 text-sm rounded-sm" placeholder="Project Name">
                                    <option value="op1">option text</option>
                                    <option value="op2">option text</option>
                                    <option value="op3">option text</option>
                                    <option value="op4">option text</option>
                                    </select>
                            </div>
                            <div class="px-3 py-2">
                                <select name="" id="" class="border border-1 w-full outline-none px-0.5 text-gray-500 text-sm rounded-sm">
                                    <option value="">RT</option>
                                    <option value="">AT</option>
                                </select>
                                <!-- <input type="text" class="border border-1 w-full outline-none px-0.5 text-gray-500 text-sm rounded-sm"> -->
                            </div>
                            <div class="px-3 py-2">
                                <select multiple class="chosen border border-1 w-full outline-none px-0.5 text-gray-500 text-sm rounded-sm" placeholder="Specify Tags">
                                <option value="op1">option text</option>
                                <option value="op2">option text</option>
                                <option value="op3">option text</option>
                                <option value="op4">option text</option>
                                </select>
                            </div>
                            <div class="px-3 py-2">
                                <input type="text" class="border border-1 w-full outline-none px-0.5 text-gray-500 text-sm rounded-sm" placeholder="Short Desc.">
                            </div>

                            <div class="px-3 py-2 text-center text-sm leading-5 text-gray-500"></div>
                            <div class="px-3 py-2 flex items-center justify-center col-span-2">
                                <input type="time" class="outline-none px-0.5 text-gray-500 text-sm border border-1 mx-0.5 rounded-sm">-<input type="time" class="outline-none px-0.5 text-gray-500 text-sm border border-1 mx-0.5 rounded-sm">
                            </div>
                            <div class="px-6 py-2 flex items-center text-sm leading-5 font-medium text-gray-500">
                                00:00:00
                            </div>
                            <div class="px-3 py-2 text-center text-sm leading-5 text-gray-500">
                                <button class="px-2 py-1 font-semibold bg-gray-500 text-white rounded-md hover:bg-gray-600 focus:outline-none">
                                            Save
                                        </button>
                            </div>
                        </div>



                    </div>
                    <!-- ////////////////////////////////////////////// top part //////////////////////////////////////////// -->
                    <div id="table1" class="shadow border-b border-gray-200 sm:rounded-lg mb-10 divide-y divide-gray-200">


                        <div class="grid custom-grid bg-gray-50 sm:rounded-t-lg">

                            <div class="col-span-2 p-3 whitespace-no-wrap text-left text-xs leading-4 font-medium text-gray-500">
                                Today - March 09, 2021
                            </div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>


                            <div class="col-span-2 p-3 text-center text-xs leading-4 font-medium text-gray-500">
                                08:00 - 20:00
                            </div>
                            <div class="col-span-2 px-6 py-3 text-left text-xs leading-4 font-medium text-gray-500 italic">
                                Total hours: 06:25:42
                            </div>


                        </div>

                        <!-- Odd row -->

                        <div class="grid custom-grid bg-white">
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                Task API - CRUD
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 font-semibold italic text-gray-500 flex items-center">
                                Timeshift Project
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                RT
                            </div>
                            <div class="p-3 text-gray-500  flex items-center">
                                <div class="flex items-center flex-wrap">
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">API</a>
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">database</a>
                                </div>
                            </div>
                            <div class="px-3 py-2 text-sm leading-5 text-left text-gray-500  flex items-center">
                                Developing the CRUD API
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center -mr-12">
                                Please prioritize
                            </div>
                            <div class="col-span-2 px-6 py-4 text-xs leading-5 text-gray-500 flex items-center justify-center">
                                08:00 - 09:30
                            </div>
                            <div class="px-6 py-2 truncate text-left flex items-center text-sm leading-5 font-medium text-gray-500">
                                01:30:00
                            </div>
                            <div class="px-6 flex items-center justify-center">

                                <div class="flex items-center justify-around w-full">
                                    <div class="relative flex flex-col">
                                        <button class="focus:outline-none comment_butt">
                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                                </button>

                                    </div>


                                    <div class="relative flex flex-col">


                                        <button class="focus:outline-none more_butt">
                                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> 
                                                                </button>


                                    </div>



                                </div>
                            </div>
                        </div>
                        <div class="grid custom-grid bg-gray-100">
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                Task API - CRUD
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 font-semibold italic text-gray-500 flex items-center">
                                Timeshift Project
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                RT
                            </div>
                            <div class="p-3 text-gray-500  flex items-center">
                                <div class="flex items-center flex-wrap">
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">API</a>
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">database</a>
                                </div>
                            </div>
                            <div class="px-3 py-2 text-sm leading-5 text-left text-gray-500  flex items-center">
                                Developing the CRUD API
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center -mr-12">
                                Please prioritize
                            </div>
                            <div class="col-span-2 px-6 py-4 text-xs leading-5 text-gray-500 flex items-center justify-center">
                                08:00 - 09:30
                            </div>
                            <div class="px-6 py-2 truncate text-left flex items-center text-sm leading-5 font-medium text-gray-500">
                                01:30:00
                            </div>
                            <div class="px-6 flex items-center justify-center">

                                <div class="flex items-center justify-around w-full">
                                    <div class="relative flex flex-col">
                                        <button class="focus:outline-none comment_butt">
                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                                </button>

                                    </div>


                                    <div class="relative flex flex-col">


                                        <button class="focus:outline-none more_butt">
                                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> 
                                                                </button>


                                    </div>



                                </div>
                            </div>
                        </div>
                        <div class="grid custom-grid bg-white">
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                Task API - CRUD
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 font-semibold italic text-gray-500 flex items-center">
                                Timeshift Project
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                RT
                            </div>
                            <div class="p-3 text-gray-500  flex items-center">
                                <div class="flex items-center flex-wrap">
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">API</a>
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">database</a>
                                </div>
                            </div>
                            <div class="px-3 py-2 text-sm leading-5 text-left text-gray-500  flex items-center">
                                Developing the CRUD API
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center -mr-12">
                                Please prioritize
                            </div>
                            <div class="col-span-2 px-6 py-4 text-xs leading-5 text-gray-500 flex items-center justify-center">
                                08:00 - 09:30
                            </div>
                            <div class="px-6 py-2 truncate text-left flex items-center text-sm leading-5 font-medium text-gray-500">
                                01:30:00
                            </div>
                            <div class="px-6 flex items-center justify-center">

                                <div class="flex items-center justify-around w-full">
                                    <div class="relative flex flex-col">
                                        <button class="focus:outline-none comment_butt">
                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                                </button>

                                    </div>


                                    <div class="relative flex flex-col">


                                        <button class="focus:outline-none more_butt">
                                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> 
                                                                </button>


                                    </div>



                                </div>
                            </div>
                        </div>
                        <div class="grid custom-grid bg-gray-100">
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                Task API - CRUD
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 font-semibold italic text-gray-500 flex items-center">
                                Timeshift Project
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                RT
                            </div>
                            <div class="p-3 text-gray-500  flex items-center">
                                <div class="flex items-center flex-wrap">
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">API</a>
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">database</a>
                                </div>
                            </div>
                            <div class="px-3 py-2 text-sm leading-5 text-left text-gray-500  flex items-center">
                                Developing the CRUD API
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center -mr-12">
                                Please prioritize
                            </div>
                            <div class="col-span-2 px-6 py-4 text-xs leading-5 text-gray-500 flex items-center justify-center">
                                08:00 - 09:30
                            </div>
                            <div class="px-6 py-2 truncate text-left flex items-center text-sm leading-5 font-medium text-gray-500">
                                01:30:00
                            </div>
                            <div class="px-6 flex items-center justify-center">

                                <div class="flex items-center justify-around w-full">
                                    <div class="relative flex flex-col">
                                        <button class="focus:outline-none comment_butt">
                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                                </button>

                                    </div>


                                    <div class="relative flex flex-col">


                                        <button class="focus:outline-none more_butt">
                                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> 
                                                                </button>


                                    </div>



                                </div>
                            </div>
                        </div>
                        <div class="grid custom-grid bg-white">
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                Task API - CRUD
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 font-semibold italic text-gray-500 flex items-center">
                                Timeshift Project
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                RT
                            </div>
                            <div class="p-3 text-gray-500  flex items-center">
                                <div class="flex items-center flex-wrap">
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">API</a>
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">database</a>
                                </div>
                            </div>
                            <div class="px-3 py-2 text-sm leading-5 text-left text-gray-500  flex items-center">
                                Developing the CRUD API
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center -mr-12">
                                Please prioritize
                            </div>
                            <div class="col-span-2 px-6 py-4 text-xs leading-5 text-gray-500 flex items-center justify-center">
                                08:00 - 09:30
                            </div>
                            <div class="px-6 py-2 truncate text-left flex items-center text-sm leading-5 font-medium text-gray-500">
                                01:30:00
                            </div>
                            <div class="px-6 flex items-center justify-center">

                                <div class="flex items-center justify-around w-full">
                                    <div class="relative flex flex-col">
                                        <button class="focus:outline-none comment_butt">
                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                                </button>

                                    </div>


                                    <div class="relative flex flex-col">


                                        <button class="focus:outline-none more_butt">
                                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> 
                                                                </button>


                                    </div>



                                </div>
                            </div>
                        </div>
                        <div class="grid custom-grid bg-gray-100">
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                Task API - CRUD
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 font-semibold italic text-gray-500 flex items-center">
                                Timeshift Project
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                RT
                            </div>
                            <div class="p-3 text-gray-500  flex items-center">
                                <div class="flex items-center flex-wrap">
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">API</a>
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">database</a>
                                </div>
                            </div>
                            <div class="px-3 py-2 text-sm leading-5 text-left text-gray-500  flex items-center">
                                Developing the CRUD API
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center -mr-12">
                                Please prioritize
                            </div>
                            <div class="col-span-2 px-6 py-4 text-xs leading-5 text-gray-500 flex items-center justify-center">
                                08:00 - 09:30
                            </div>
                            <div class="px-6 py-2 truncate text-left flex items-center text-sm leading-5 font-medium text-gray-500">
                                01:30:00
                            </div>
                            <div class="px-6 flex items-center justify-center">

                                <div class="flex items-center justify-around w-full">
                                    <div class="relative flex flex-col">
                                        <button class="focus:outline-none comment_butt">
                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                                </button>

                                    </div>


                                    <div class="relative flex flex-col">


                                        <button class="focus:outline-none more_butt">
                                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> 
                                                                </button>


                                    </div>



                                </div>
                            </div>
                        </div>
                        <div class="grid custom-grid bg-white">
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                Task API - CRUD
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 font-semibold italic text-gray-500 flex items-center">
                                Timeshift Project
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                RT
                            </div>
                            <div class="p-3 text-gray-500  flex items-center">
                                <div class="flex items-center flex-wrap">
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">API</a>
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">database</a>
                                </div>
                            </div>
                            <div class="px-3 py-2 text-sm leading-5 text-left text-gray-500  flex items-center">
                                Developing the CRUD API
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center -mr-12">
                                Please prioritize
                            </div>
                            <div class="col-span-2 px-6 py-4 text-xs leading-5 text-gray-500 flex items-center justify-center">
                                08:00 - 09:30
                            </div>
                            <div class="px-6 py-2 truncate text-left flex items-center text-sm leading-5 font-medium text-gray-500">
                                01:30:00
                            </div>
                            <div class="px-6 flex items-center justify-center">

                                <div class="flex items-center justify-around w-full">
                                    <div class="relative flex flex-col">
                                        <button class="focus:outline-none comment_butt">
                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                                </button>

                                    </div>


                                    <div class="relative flex flex-col">


                                        <button class="focus:outline-none more_butt">
                                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> 
                                                                </button>


                                    </div>



                                </div>
                            </div>
                        </div>
                        <div class="grid custom-grid bg-gray-100 sm:rounded-b-lg">
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                Task API - CRUD
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 font-semibold italic text-gray-500 flex items-center">
                                Timeshift Project
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
                                RT
                            </div>
                            <div class="p-3 text-gray-500  flex items-center">
                                <div class="flex items-center flex-wrap">
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">API</a>
                                    <a href="#" class="text-sm px-2 m-0.5 border border-1 border-gray-200 rounded-lg">database</a>
                                </div>
                            </div>
                            <div class="px-3 py-2 text-sm leading-5 text-left text-gray-500  flex items-center">
                                Developing the CRUD API
                            </div>
                            <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center -mr-12">
                                Please prioritize
                            </div>
                            <div class="col-span-2 px-6 py-4 text-xs leading-5 text-gray-500 flex items-center justify-center">
                                08:00 - 09:30
                            </div>
                            <div class="px-6 py-2 truncate text-left flex items-center text-sm leading-5 font-medium text-gray-500">
                                01:30:00
                            </div>
                            <div class="px-6 flex items-center justify-center">

                                <div class="flex items-center justify-around w-full">
                                    <div class="relative flex flex-col">
                                        <button class="focus:outline-none comment_butt">
                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                                </button>

                                    </div>


                                    <div class="relative flex flex-col">


                                        <button class="focus:outline-none more_butt">
                                                                    <svg class="w-6 h-6 text-gray-500 " fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> 
                                                                </button>


                                    </div>



                                </div>
                            </div>
                        </div>





                    </div>

                </div>
                <!-- ////////////////////////////////////////////////////// Task Tracker ////////////////////////////////////////////////////////// -->



                <!-- ////////////////////////////////////////////////////// Attendance ////////////////////////////////////////////////////////// -->
                <div id="attendance_content" class="align-middle w-full sm:p-6 lg:px-8 hidden">
                    <div class="text-3xl font-bold text-gray-700">
                        Attendance
                    </div>

                </div>
                <!-- ////////////////////////////////////////////////////// Attendance ////////////////////////////////////////////////////////// -->



                <!-- ////////////////////////////////////////////////////// Daily time-sheet ////////////////////////////////////////////////////////// -->
                <div id="daily_time_sheet_content" class="align-middle w-full sm:p-6 lg:px-8 hidden">
                    <div class="text-3xl font-bold text-gray-700">
                        Daily time-sheet
                    </div>

                </div>
                <!-- ////////////////////////////////////////////////////// Daily time-sheet ////////////////////////////////////////////////////////// -->

                <!-- ////////////////////////////////////////////////////// Settings ////////////////////////////////////////////////////////// -->
                <div id="settings_content" class="align-middle w-full sm:p-6 lg:px-8 hidden">
                    <div class="text-3xl font-bold text-gray-700">
                        Settings
                    </div>

                </div>
                <!-- ////////////////////////////////////////////////////// Settings ////////////////////////////////////////////////////////// -->

                <!-- /////////////////////////////////////////// delete popup /////////////////////////////////////////// -->
                <div id="del_popup" class="fixed z-10 inset-0 overflow-y-auto hidden">
                    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                        <div class="fixed inset-0 transition-opacity">
                            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
                        </div>

                        <!-- This element is to trick the browser into centering the modal contents. -->
                        <span class="hidden sm:inline-block sm:align-middle sm:h-screen"></span>&#x200B;

                        <div class="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6" role="dialog" aria-modal="true" aria-labelledby="modal-headline">
                            <div class="sm:flex sm:items-start">
                                <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
                                    <!-- Heroicon name: exclamation -->
                                    <svg class="h-6 w-6 text-red-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
                                </div>
                                <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">

                                    <div class="mt-2">
                                        <h3 class="text-base leading-6 font-medium text-gray-600">
                                            Are you sure you want to delete the user: <b> User </b>?
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-5 sm:mt-4 sm:ml-10 sm:pl-4 sm:flex">
                                <span class="flex w-full rounded-md shadow-sm sm:w-auto">
        <button type="button" class="inline-flex justify-center w-full rounded-md border border-transparent px-4 py-2 bg-red-600 text-base leading-6 font-medium text-white shadow-sm hover:bg-red-500 focus:outline-none focus:border-red-700 focus:shadow-outline-red transition ease-in-out duration-150 sm:text-sm sm:leading-5">
          Delete
        </button>
      </span>
                                <span class="mt-3 flex w-full rounded-md shadow-sm sm:mt-0 sm:ml-3 sm:w-auto">
        <button type="button" class="inline-flex justify-center w-full rounded-md border border-gray-300 px-4 py-2 bg-white text-base leading-6 font-medium text-gray-700 shadow-sm hover:text-gray-500 focus:outline-none focus:border-blue-300 focus:shadow-outline-blue transition ease-in-out duration-150 sm:text-sm sm:leading-5" onclick="ShowHidedel()">
          Cancel
        </button>
      </span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /////////////////////////////////////////// delete popup /////////////////////////////////////////// -->


                <!-- /////////////////////////////////////////// Edit popup /////////////////////////////////////////// -->
                <div id="edit_popup" class="fixed z-10 inset-0 overflow-y-auto hidden">
                    <div class="flex items-center justify-center min-h-screen px-4 sm:p-0 bg-gray-500 bg-opacity-75">

                        <form class="w-1/4 mx-auto bg-white p-5 rounded-lg">
                            <div>
                                <div class="pt-2">
                                    <div>
                                        <h3 class="text-lg leading-6 font-medium text-gray-900">
                                            Edit user
                                        </h3>
                                        <input class="actionEdit" value="" type="hidden">
                                    </div>
                                    <div class="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                                        <div class="sm:col-span-6">
                                            <label for="name" class="block text-sm font-medium leading-5 text-gray-700">
                              Name
                            </label>
                                            <div class="mt-1">
                                                <input required id="name" class="form-input border border-gray-400 rounded-md py-1 px-2 focus:outline-none text-gray-700 block w-full transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                                            </div>
                                        </div>

                                        <div class="sm:col-span-6">
                                            <label for="email" class="block text-sm font-medium leading-5 text-gray-700">
                              Email address
                            </label>
                                            <div class="mt-1 rounded-md shadow-sm">
                                                <input required id="email" type="email" class="form-input border border-gray-400 rounded-md py-1 px-2 focus:outline-none text-gray-700 block w-full transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                                            </div>
                                        </div>


                                        <div class="sm:col-span-6">
                                            <label for="street_address" class="block text-sm font-medium leading-5 text-gray-700">
                              Job
                            </label>
                                            <div class="mt-1 rounded-md shadow-sm">
                                                <input required id="street_address" class="form-input border border-gray-400 rounded-md py-1 px-2 focus:outline-none text-gray-700 block w-full transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                                            </div>
                                        </div>

                                        <div class="sm:col-span-6">
                                            <label for="city" class="block text-sm font-medium leading-5 text-gray-700">
                              Password
                            </label>
                                            <div class="mt-1 rounded-md shadow-sm">
                                                <input required type="password" id="city" class="form-input border border-gray-400 rounded-md py-1 px-2 focus:outline-none text-gray-700 block w-full transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-8 border-t border-gray-200 pt-5">
                                <div class="flex justify-end">
                                    <span class="inline-flex rounded-md shadow-sm">
                          <button type="button" class="py-2 px-4 border border-gray-300 rounded-md text-sm leading-5 font-medium text-gray-700 hover:text-gray-500 focus:outline-none focus:border-blue-300 focus:shadow-outline-blue active:bg-gray-50 active:text-gray-800 transition duration-150 ease-in-out "  onclick="ShowHideedit()">
                            Cancel
                          </button>
                        </span>
                                    <span class="ml-3 inline-flex rounded-md shadow-sm">
                          <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent text-sm leading-5 font-medium rounded-md text-white bg-gray-600 hover:bg-gray-500 focus:outline-none focus:border-gray-700 focus:shadow-outline-indigo active:bg-indigo-700 transition duration-150 ease-in-out">
                            Save
                          </button>
                        </span>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /////////////////////////////////////////// Edit popup /////////////////////////////////////////// -->

                <!-- /////////////////////////////////////////// Invite popup /////////////////////////////////////////// -->
                <div id="invite_popup" class="fixed z-10 inset-0 overflow-y-auto hidden">
                    <div class="flex items-center justify-center min-h-screen px-4 sm:p-0 bg-gray-500 bg-opacity-75">

                        <form class="w-1/4 mx-auto bg-white p-5 rounded-lg">
                            <div>
                                <div class="pt-2">
                                    <div>
                                        <h3 class="text-lg leading-6 font-medium text-gray-900">
                                            Invite user
                                        </h3>
                                    </div>
                                    <div class="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">


                                        <div class="sm:col-span-6">
                                            <label for="email" class="block text-sm font-medium leading-5 text-gray-700">
                              Email address
                            </label>
                                            <div class="mt-1 rounded-md shadow-sm">
                                                <input required id="email" type="email" class="form-input border border-gray-400 rounded-md py-1 px-2 focus:outline-none text-gray-700 block w-full transition duration-150 ease-in-out sm:text-sm sm:leading-5" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-8 border-t border-gray-200 pt-5">
                                <div class="flex justify-end">
                                    <span class="inline-flex rounded-md shadow-sm">
                          <button type="button" class="py-2 px-4 border border-gray-300 rounded-md text-sm leading-5 font-medium text-gray-700 hover:text-gray-500 focus:outline-none focus:border-blue-300 focus:shadow-outline-blue active:bg-gray-50 active:text-gray-800 transition duration-150 ease-in-out "  onclick="ShowHideinv()">
                            Cancel
                          </button>
                        </span>
                                    <span class="ml-3 inline-flex rounded-md shadow-sm">
                          <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent text-sm leading-5 font-medium rounded-md text-white bg-gray-600 hover:bg-gray-500 focus:outline-none focus:border-gray-700 focus:shadow-outline-indigo active:bg-indigo-700 transition duration-150 ease-in-out">
                            Invite
                          </button>
                        </span>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /////////////////////////////////////////// Invite popup /////////////////////////////////////////// -->

                <!-- /////////////////////////////////////////// Profile popup /////////////////////////////////////////// -->
                <div id="profile_popup" class="fixed z-10 inset-0 overflow-y-auto hidden">
                    <div class="flex items-center justify-center min-h-screen px-4 sm:p-0 bg-gray-500 bg-opacity-75">
                        <div class="w-1/2 mx-auto">
                            <form action="#" method="POST">
                                <div class="shadow sm:rounded-md sm:overflow-hidden">
                                    <div class="bg-white py-6 px-4 space-y-6 sm:p-6">
                                        <div class="flex justify-between">
                                            <h2 class="text-lg leading-6 font-medium text-gray-900">Profile</h2>
                                            <button type="button" class="focus:outline-none text-gray-700" onclick="toggleprofile()">
                                                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path></svg>
                                            </button>
                                        </div>



                                        <div class="space-y-1">
                                            <div class="col-span-3 space-y-1 mb-4">
                                                <label class="block text-sm leading-5 font-medium text-gray-700">
                              Photo
                            </label>
                                                <div class="flex items-center">
                                                    <span class="inline-block bg-gray-100 rounded-full overflow-hidden h-16 w-16">
                                <svg class="h-full w-full text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                                  <path d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z" />
                                </svg>
                              </span>
                                                    <span class="ml-5 rounded-md shadow-sm">
                                <button type="button" class="border border-gray-300 rounded-md py-2 px-3 text-sm leading-4 font-medium text-gray-700 hover:text-gray-500 focus:outline-none focus:border-blue-300 focus:shadow-outline-blue active:bg-gray-50 active:text-gray-800 transition duration-150 ease-in-out">
                                  Change
                                </button>
                              </span>
                                                </div>
                                            </div>
                                            <div class="grid grid-cols-6 gap-6">
                                                <div class="col-span-6 sm:col-span-3">
                                                    <label for="first_name" class="block text-sm font-medium leading-5 text-gray-700">Username</label>
                                                    <input id="first_name" class="form-input mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5" value="User"
                                                    />
                                                </div>
                                            </div>
                                        </div>


                                        <div>
                                            <h2 class="text-lg leading-6 font-medium text-gray-900">Personal Information</h2>
                                        </div>

                                        <div class="grid grid-cols-6 gap-6">
                                            <div class="col-span-6 sm:col-span-3">
                                                <label for="first_name" class="block text-sm font-medium leading-5 text-gray-700">First name</label>
                                                <input id="first_name" required value="First" class="form-input mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5"
                                                />
                                            </div>

                                            <div class="col-span-6 sm:col-span-3">
                                                <label for="last_name" class="block text-sm font-medium leading-5 text-gray-700">Last name</label>
                                                <input id="last_name" required value="User" class="form-input mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5"
                                                />
                                            </div>
                                            <div class="col-span-6 sm:col-span-3">
                                                <label for="mail_profile" class="block text-sm font-medium leading-5 text-gray-700">Email</label>
                                                <input id="mail_profile" type="email" required value="user@mail.com" class="form-input mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5"
                                                />
                                            </div>

                                            <div class="col-span-6 sm:col-span-3">
                                                <label for="phone_profile" class="block text-sm font-medium leading-5 text-gray-700">Phone</label>
                                                <input id="phone_profile" type="tel" required value="03123123" class="form-input mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5"
                                                />
                                            </div>

                                            <div class="col-span-6 sm:col-span-4">
                                                <label for="password" class="block text-sm font-medium leading-5 text-gray-700">Password</label>
                                                <input id="password" type="password" required value="User123@" class="form-input mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out sm:text-sm sm:leading-5"
                                                />
                                            </div>


                                        </div>



                                    </div>
                                    <div class="px-4 py-3 bg-gray-50 flex justify-between items-center sm:px-6">
                                        <span class="italic text-sm font-semibold text-gray-500">Joined: 2021-04-05 12:24:49</span>
                                        <button type="submit" class="bg-gray-600 border border-transparent rounded-md py-2 px-4 inline-flex justify-center text-sm leading-5 font-medium text-white hover:bg-gray-500 focus:outline-none focus:border-gray-700 focus:shadow-outline-indigo active:bg-indigo-700 transition duration-150 ease-in-out">
                                Save
                              </button>

                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- /////////////////////////////////////////// Profile popup /////////////////////////////////////////// -->





            </main>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/chosen.jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/script2.js')); ?>"></script>


<script>
jQuery(document).ready(function(){
jQuery(".chosen").chosen({
    width: "95%",
    no_results_text: "No result found. Press enter to add "
  }
).on('chosen:no_results', function(evt, data){
  //console.log(evt, data, data.chosen.get_search_text(), jQuery(data.chosen.form_field));
  jQuery(data.chosen.container).on('keydown', function( event ){
      console.log(jQuery(data.chosen.form_field).find('option[value="' + data.chosen.get_search_text() + '"]').length);
    
    if( 13 == event.keyCode && ! jQuery(data.chosen.form_field).find('option[value="' + data.chosen.get_search_text() + '"]').length ){
      jQuery(data.chosen.form_field).append('<option value="' + data.chosen.get_search_text() + '" selected>' + data.chosen.get_search_text() + '</option>');
  jQuery(data.chosen.form_field).trigger('chosen:updated');
 data.chosen.result_highlight = data.chosen.search_results.find('li.active-result').lasteturn;
    data.chosen.result_select(evt);
    }
    });
});
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tailwind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Timeshift\resources\views/admin/latesttest.blade.php ENDPATH**/ ?>