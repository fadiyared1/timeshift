
<?php $__env->startSection('content'); ?>
<?php if(session('message')): ?>
   <div class="alert alert-success">
      <?php echo e(session('message')); ?>

   </div>
<?php endif; ?>
<div id="wrapper">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<?php if($user !== null): ?>
<h2>Are You Sure You Want To Delete The User:</h2>
<h1><?php echo e($user->name); ?></h1>
</div>
<button><a href="/admin/user/<?php echo e($user->id); ?>/">Yes</a></button>
</form>
<?php endif; ?>
<button><a href="<?php echo e(route('users')); ?>">No</a></button>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Timeshift\resources\views/admin/delete.blade.php ENDPATH**/ ?>