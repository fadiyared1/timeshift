
<?php $__env->startSection('content'); ?>
<?php if(session('message')): ?>
   <div class="alert alert-success">
      <?php echo e(session('message')); ?>

   </div>
<?php endif; ?>
<title>Users</title>
<table class="table">
    <thead>
      <tr>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
        <th scope="col">Created at</th>
        <th scope="col">Role</th>
        <th scope="col">Delete</th>
        <th scope="col">Suspend/Activate</th>
        <th scope="col">Edit</th>
        <th scope="col">Resend Invitation</th>
      </tr>
    </thead>
    <tbody>
     <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->email); ?></td>
        <td><?php echo e($user->created_at); ?></td>
        <?php if($user->hasRole(['user'])): ?>
        <td>User</td>
        <td><a href="/admin/<?php echo e($user->id); ?>/delete">Delete</a></td>
        <?php if($user->suspend == 0): ?>
        <td><a href="/admin/<?php echo e($user->id); ?>/suspend">Suspend</a></td>
        <?php else: ?>
        <td><a href="/admin/<?php echo e($user->id); ?>/open">Activate</a></td>
        <?php endif; ?>
        <td><a href="/admin/<?php echo e($user->id); ?>/edit">Edit</a></td>
        <td>
        <?php if($user->email_verified_at == null): ?>
        <a href="/admin/<?php echo e($user->id); ?>/resend">Resend</a>
        <?php endif; ?>
        </td>
        <?php endif; ?>
        <?php if($user->hasRole(['administrator'])): ?>
        <td>Admin</td>
        <?php endif; ?>
      </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Timeshift\resources\views/admin/users.blade.php ENDPATH**/ ?>