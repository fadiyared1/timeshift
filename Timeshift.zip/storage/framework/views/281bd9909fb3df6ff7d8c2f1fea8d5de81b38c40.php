
<?php $__env->startSection('content'); ?>
<?php if(session('message')): ?>
   <div class="alert alert-success">
      <?php echo e(session('message')); ?>

   </div>
<?php endif; ?>
<h1>Enter the email address of the new user</h1>
<form method="POST" action="<?php echo e(route('adregister')); ?>">
  <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <input type="email" class="form-control" id="email" name="email" placeholder="Enter email">
    </div>
    <input type="hidden" id="name" name="name" value="<?php echo e($name); ?>">
    <input type="hidden" id="password" name="password" value="password">
    <button type="submit" class="btn btn-dark">Submit</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Timeshift\resources\views/admin/newuser.blade.php ENDPATH**/ ?>