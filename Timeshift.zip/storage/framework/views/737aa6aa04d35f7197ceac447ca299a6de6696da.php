Press on the link below to activate your account!!
<?php echo e($link); ?>

Note that this link will expire after 60 minutes please contact your administrator in case of expiration.
<?php /**PATH C:\xampp\htdocs\Timeshift\resources\views/auth/passwords/conflink.blade.php ENDPATH**/ ?>