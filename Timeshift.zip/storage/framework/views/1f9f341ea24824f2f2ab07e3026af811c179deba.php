
<?php $__env->startSection('content'); ?>
<?php if(session('message')): ?>
   <div class="alert alert-success">
      <?php echo e(session('message')); ?>

   </div>
<?php endif; ?>
<table class="table table-bordered table-sm ">
    <thead class="thead-dark">
      <tr>
        <th scope="col">Task</th>
        <th scope="col">Project</th>
        <th scope="col">Type</th>
        <th scope="col">Tags</th>
        <th scope="col">Description</th>
        <th scope="col">Latest Comments</th>
        <th scope="col">Date</th>
        <th scope="col">Start - End</th>
        <th scope="col">Total</th>   
      </tr>
    </thead>
    <tbody>
     <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <!--<?php echo e($i=0); ?>-->
     <tr class="table-secondary clickable" data-toggle="collapse" data-target="#group-of-rows-<?php echo e($user->id); ?>" aria-expanded="false" aria-controls="group-of-rows-<?php echo e($user->id); ?>">
      <td colspan="9" style="text-align: center"  class="thead-dark"><i class="fa fa-folder-open"><?php echo e($user->name); ?></th>
      </tr>
    </tbody>
    
      <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($task->user_id == $user->id): ?>
      <!--<?php echo e($i++); ?>-->
      <tbody id="group-of-rows-<?php echo e($user->id); ?>" class="collapse">
      <tr class="table-warning">
        <td><i class="fa fa-folder-open"><?php echo e($task->name); ?></i></th>
        <td><?php echo e($task->project); ?></td>
        <td><?php echo e($task->Type); ?></td>
        <td>
          <?php $__currentLoopData = $task->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($tag->name); ?>,
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td><?php echo e($task->description); ?></td>
        <td><?php echo e($task->latestComment); ?></td>
        <td><?php echo e($task->day); ?></td>
        <td><?php echo e($task->start); ?> - <?php echo e($task->end); ?></td>
       <td>
       <?php echo e(\Carbon\Carbon::parse($task->start)->diff(\Carbon\Carbon::parse($task->end))->format('%H:%i:%s')); ?></td>
      </tr>  
     </tbody>      
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php if($i==0): ?>
      <tbody id="group-of-rows-<?php echo e($user->id); ?>" class="collapse">
        <tr class="table-warning">
          <td colspan="9"><i class="fa fa-folder-open">No Tasks Yet()</i></td>
        </tr>
      </tbody>
      <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Timeshift\resources\views/admin/index.blade.php ENDPATH**/ ?>