
<?php $__env->startSection('content'); ?>
<div id="users_content" class="align-middle w-full sm:px-6 py-6">

    <?php if(session('success')): ?>
    <div id="sucgreen" class="px-3 py-2 mb-5 border border-green-800 rounded border-l-8 bg-green-200 text-sm text-green-700">
       <?php echo e(session('success')); ?>

    </div>
 <?php endif; ?>
 <?php if(session('error')): ?>
   <div id="error" class="px-3 py-2 mb-5 border border-red-800 rounded border-l-8 bg-red-200 text-sm text-red-700">
         <?php echo e(session('error')); ?>

   </div>
 <?php endif; ?>


<div id="table1" class="shadow border-b border-gray-200 sm:rounded-lg mb-10 divide-y divide-gray-200">

    <div class="grid custom-grid bg-gray-50 sm:rounded-t-lg">
        <div class="col-span-2 p-3 whitespace-no-wrap text-left text-sm leading-4 font-medium text-gray-500">
            Project
        </div>
        <div class="col-span-8 p-3 whitespace-no-wrap text-left text-sm leading-4 font-medium text-gray-500">
           Total Work Today
        </div>
    </div>

    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="grid custom-grid bg-white <?php if($pro->id == $proj){ echo 'bg-gray-200';} ?> ">
        <div class="px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center col-span-2">
            <?php echo e($pro->name); ?>

        </div>
        <div class="col-span-7 px-3 py-2 text-left text-sm leading-5 text-gray-500 flex items-center">
            
            <?php $__currentLoopData = $pro->worktoday(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($task->user()->name); ?> : <?php if($task->end != '00:00:00'): ?><?php echo e(\Carbon\Carbon::parse($task->start)->diff(\Carbon\Carbon::parse($task->end))->format('%H:%i:%s')); ?> <?php else: ?> Started at <?php echo e($task->start); ?> and still pending <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tailwind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Timeshift\resources\views/admin/projects.blade.php ENDPATH**/ ?>