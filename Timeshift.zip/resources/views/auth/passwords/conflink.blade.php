Press on the link below to activate your account!!
{{$link}}
Note that this link will expire after 60 minutes please contact your administrator in case of expiration.
